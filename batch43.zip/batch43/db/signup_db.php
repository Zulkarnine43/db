<?php

include("config.php");

$name=$_POST['name'];
$email=$_POST['email'];
$gender=$_POST['gender'];
$password=$_POST['password'];
$Confirm_password=$_POST['Confirm_password'];

$sql="INSERT INTO cu_info (name,email,gender,password,Confirm_password) VALUES ('$name','$email','$gender','$password','$Confirm_password')";

$result=mysqli_query($con,$sql);

if($result===TRUE){
 echo"Insert Successfully";
}
else{
	echo"Insert Error";
}


?>