
	<ul>
		<li><a href="index.php"> Home</a> </li>
		<li> <a href="signup.php">Signup</a></li>
		<li> <a href="education.html">Education</a></li>
		<li> <a href="cv.html">CV</a></li>
		<li> <a href="contact.html">Contact</a></li>

	</ul>
