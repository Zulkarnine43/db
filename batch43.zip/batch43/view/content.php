	<table width="80%"  border="1px" align="center">
			<tr>
				<th  colspan="3">Weekly Class Routine</th>

			</tr>
			<tr>
				<th >Day</th>
				<th  >Subject</th>
				<th >Teachers Name</th>
			</tr>

			<tr>
				<th rowspan="3">Sun<sub>day</sub><br>Tues<sup>day</sup></th>
				<td>Web Database</td>
				<td>Md Ataullah Bhuiyan</td>
			</tr>
			<tr>
				<td>Web Database Labratory</td>
				<td>Md Ataullah Bhuiyan</td>
			</tr>

			<tr>
				<td>computer modeling & simulation</td>
				<td>Fahim Shahriar Mahin</td>
			</tr>

			<tr>
				<th rowspan="2">Mon<sub>day</sub><br>Wednes<sup>day</sup></th>
				<td>Software Quality Assurence</td>
				<td>Trina Saha</td>
			</tr>

			<tr>
				<td>System Programming</td>
				<td>Sharmin Akter</td>
			</tr>


		</table>