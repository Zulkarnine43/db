<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> HOME</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
</html>