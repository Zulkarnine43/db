<?php
include("../db/config.php");
?>
<p style="margin-left:500px; display: inline">Developed by <a><b style="color:black">Zulkar Nine <?php echo $writter ?></b></a></p>
