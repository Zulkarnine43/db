
<body>

	<div id="head">
	<?php
       include("header.php");
	?>
	<img src="../img/cu.jpg"  style="width:100%; height: 150px;" alt="img">

	</div>

		<div id="menu"> 
	<?php
       include("menu.php");
	?>
	
	</div>


	<div id=sbar>
     <?php
       include("sideBer.php");
	?>

	</div>


	<div id="cont">
		  <?php
       include("content.php");
	?>
	
	</div>
	
	<div id="footer">
    <?php
       include("footer.php");
	?>
	</div>
	
</body>

